package io.springboot;

import io.beans.Topics;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
//@EnableWebSecurity
public class CourseController {
	
	@Autowired(required=true)
	private CourseService service;
	
	@RequestMapping("/hello")
	public String sayHello(){
		return "Hi........!";
	}
	@RequestMapping("/getAllTopics")
	public List<Topics> getAllTopics(){
		return service.getAllTopics();
	}
	
}
