package io.springboot;

import io.beans.Topics;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

import org.springframework.stereotype.Service;

@Service
public class CourseService {

	List<Topics> topics = Arrays.asList(
			new Topics("corejava","C java","core java topics"),
			new Topics("Advance java","A java","Advance java topics"),
			new Topics("Spring","Spring java","Spring framework")
			
			);
	
	public List<Topics> getAllTopics(){
		return topics;
	}
	
	/*public Topics getTopic(String id){
		return topics.stream().filter(i->i.);
	}*/
}
